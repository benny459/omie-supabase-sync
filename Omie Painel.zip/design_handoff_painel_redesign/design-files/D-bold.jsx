// Variação D — "Bold/Comando-K-First"
// Aposta criativa: tabela "agente" com comando-K central (cmdk omnipresente),
// PV/OS como cards-de-board (não buckets em tabela), itens como sub-rows
// com timeline horizontal (PV → RC → PC → Aprovação → Logística), KPIs
// reduzidos a um sparkline-strip. Pensado pra usuário que vive no app:
// menos ornamentação, mais ação. Tom: editorial, "ferramenta de poder".

const D_TOKENS = {
  light: {
    bg: "#f4f4f0", panel: "#ffffff", border: "#e3e3dc", borderStrong: "#c8c8be",
    text: "#0e0e0c", textMuted: "#5b5b54", textFaint: "#8e8e84",
    accent: "#0e6e57", accentSoft: "#dbeee5", ink: "#0e0e0c",
    bucket: "#ebebe4", yellow: "#fbf1b3", yellowBorder: "#cfb742",
  },
  dark: {
    bg: "#0a0a08", panel: "#131311", border: "#22221d", borderStrong: "#33332b",
    text: "#f1f1ea", textMuted: "#a8a89e", textFaint: "#6c6c61",
    accent: "#3eba9a", accentSoft: "#15302a", ink: "#f1f1ea",
    bucket: "#16161300", yellow: "#3a3416", yellowBorder: "#6e6024",
  },
};

const D_STATUS = {
  light: {
    APROVADO: ["#0e6e57", "#fff"], APROVADO_FAT_DIRETO: ["#0e6493", "#fff"],
    PRE_SELECAO: ["#b8651a", "#fff"], PENDENTE: ["#0e0e0c", "#fff"],
    NAO_APROVADO: ["#5223a4", "#fff"], REJEITADO_VALIDADE: ["#7c4ec4", "#fff"],
    CANCELAR_PEDIDO: ["#b8253a", "#fff"], N_A: ["#8e8e84", "#fff"],
  },
  dark: {
    APROVADO: ["#3eba9a", "#0a1812"], APROVADO_FAT_DIRETO: ["#5cb6ed", "#0a1622"],
    PRE_SELECAO: ["#e8a04a", "#1a0e02"], PENDENTE: ["#f1f1ea", "#0a0a08"],
    NAO_APROVADO: ["#ad8af0", "#1a0e2c"], REJEITADO_VALIDADE: ["#c2a8e8", "#251a35"],
    CANCELAR_PEDIDO: ["#ed5f7a", "#280a10"], N_A: ["#a8a89e", "#16160e"],
  },
};

function DPane({ mode }) {
  const t = D_TOKENS[mode];
  const status = D_STATUS[mode];
  const summary = summarize();
  const fontStack = `"Söhne", "Inter", -apple-system, system-ui, sans-serif`;
  const monoStack = `"Berkeley Mono", "JetBrains Mono", ui-monospace, "SF Mono", monospace`;

  return (
    <div style={{ background: t.bg, color: t.text, fontFamily: fontStack, fontSize: 13, lineHeight: 1.5, height: "100%", display: "flex", flexDirection: "column", padding: "16px 18px", gap: 12 }}>
      {/* Top bar — minimal, command-bar-first */}
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ fontFamily: monoStack, fontSize: 11.5, color: t.textMuted, letterSpacing: 0.5 }}>WW · COMPRAS</div>
        <span style={{ width: 3, height: 3, borderRadius: 999, background: t.textFaint }} />
        <div style={{ fontSize: 12, color: t.textMuted }}>vendas avulsas / 1.783 itens</div>
        <div style={{ flex: 1 }} />
        <div style={{ display: "flex", gap: 4, fontSize: 11.5, color: t.textMuted }}>
          <span style={{ padding: "3px 8px", borderRadius: 5, background: t.panel, border: `1px solid ${t.border}` }}>Avulsas</span>
          <span style={{ padding: "3px 8px", borderRadius: 5, color: t.textFaint }}>Projetos</span>
          <span style={{ padding: "3px 8px", borderRadius: 5, color: t.textFaint }}>PCs</span>
        </div>
        <span style={{ fontFamily: monoStack, fontSize: 10.5, color: t.textFaint }}>sync 12m</span>
      </div>

      {/* Hero command bar */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px", background: t.panel, border: `1px solid ${t.border}`, borderRadius: 10, boxShadow: mode === "light" ? "0 1px 0 rgba(0,0,0,.04), 0 8px 24px -16px rgba(0,0,0,.12)" : "none" }}>
        <span style={{ fontFamily: monoStack, fontSize: 10.5, color: t.textFaint, letterSpacing: 1, textTransform: "uppercase" }}>⌘K</span>
        <div style={{ width: 1, height: 16, background: t.border }} />
        <div style={{ flex: 1, fontSize: 14, color: t.textMuted }}>
          <span style={{ color: t.text, fontWeight: 500 }}>Aprovar</span>
          <span style={{ color: t.textFaint }}> · </span>
          <span>filtrar por fornecedor "KSB" e status pendente · ou apenas digite</span>
        </div>
        <span style={{ fontFamily: monoStack, fontSize: 10.5, color: t.textFaint, padding: "2px 6px", border: `1px solid ${t.border}`, borderRadius: 4 }}>tab</span>
      </div>

      {/* KPI strip — minimal, inline, with mini sparkline */}
      <div style={{ display: "flex", gap: 0, padding: "0", border: `1px solid ${t.border}`, borderRadius: 10, background: t.panel, overflow: "hidden" }}>
        {[
          { label: "Aprovados",     value: summary.aprov,    spark: [4,5,7,6,8,9,11,10,12,13], tone: status.APROVADO },
          { label: "Pendentes",     value: summary.pend,     spark: [9,8,10,7,8,9,7,6,8,7],   tone: status.PENDENTE },
          { label: "Não aprovados", value: summary.naoAprov, spark: [2,3,2,4,3,2,3,4,3,3],   tone: status.NAO_APROVADO },
          { label: "Atrasados",     value: summary.atras,    spark: [1,2,2,3,3,4,4,3,4,4],   tone: status.PRE_SELECAO },
          { label: "Sem projeto",   value: summary.semProj,  spark: [3,2,2,2,1,1,1,1,1,1],   tone: status.N_A },
        ].map((k, i, arr) => (
          <div key={k.label} style={{ flex: 1, padding: "12px 16px", borderRight: i < arr.length - 1 ? `1px solid ${t.border}` : "none", display: "flex", flexDirection: "column", gap: 4 }}>
            <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
              <span style={{ fontSize: 22, fontWeight: 600, letterSpacing: -0.6, fontVariantNumeric: "tabular-nums", fontFamily: monoStack }}>{fmtNum(k.value)}</span>
              <DSpark data={k.spark} color={k.tone[0]} />
            </div>
            <div style={{ fontSize: 11, color: t.textMuted, letterSpacing: 0.4, textTransform: "uppercase", fontWeight: 500 }}>{k.label}</div>
          </div>
        ))}
      </div>

      {/* Bucket cards — each PV/OS is a card with horizontal pipeline */}
      <div style={{ flex: 1, overflow: "auto", display: "flex", flexDirection: "column", gap: 10 }}>
        {BUCKETS.slice(0, 4).map((b) => <DBucketCard key={b.pv_os} bucket={b} t={t} status={status} mode={mode} mono={monoStack} />)}
      </div>

      <div style={{ position: "absolute", top: 8, right: 12, fontSize: 10.5, color: t.textFaint, letterSpacing: 0.5, textTransform: "uppercase", fontWeight: 600 }}>{mode}</div>
    </div>
  );
}

function DSpark({ data, color }) {
  const w = 60, h = 16;
  const max = Math.max(...data), min = Math.min(...data);
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / (max - min || 1)) * h}`).join(" ");
  return (
    <svg width={w} height={h} style={{ display: "block" }}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.4" strokeLinejoin="round" strokeLinecap="round" opacity="0.85" />
    </svg>
  );
}

function DBucketCard({ bucket, t, status, mode, mono }) {
  const total = bucket.items.reduce((s, i) => s + i.valor_pc, 0);
  // Pipeline: PV emitido → RC criada → PC emitido → Aprovação → Logística
  const stages = [
    { label: "PV/OS",      done: true,  detail: bucket.pv_os },
    { label: "RC",         done: bucket.items.some(i => i.rc !== "—"), detail: `${bucket.items.length} itens` },
    { label: "PC",         done: bucket.items.some(i => i.pc), detail: bucket.items.filter(i => i.pc).length + " emitidos" },
    { label: "Aprovação",  done: bucket.items.some(i => i.status === "APROVADO" || i.status === "APROVADO_FAT_DIRETO"), detail: bucket.items.filter(i => i.status === "APROVADO" || i.status === "APROVADO_FAT_DIRETO").length + " ok" },
    { label: "Logística",  done: false, detail: "aguardando" },
  ];
  return (
    <div style={{ background: t.panel, border: `1px solid ${t.border}`, borderRadius: 10, overflow: "hidden" }}>
      {/* Header: PV/OS title + pipeline + value */}
      <div style={{ padding: "12px 16px", display: "grid", gridTemplateColumns: "180px 1fr 140px", gap: 16, alignItems: "center", borderBottom: `1px solid ${t.border}`, background: mode === "dark" ? "#16161200" : "#fafaf6" }}>
        <div>
          <div style={{ fontFamily: mono, fontSize: 13, fontWeight: 600, letterSpacing: -0.2 }}>{bucket.pv_os}</div>
          <div style={{ fontSize: 11.5, color: t.textMuted, marginTop: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{bucket.cliente}</div>
        </div>
        <DPipeline stages={stages} t={t} />
        <div style={{ textAlign: "right" }}>
          <div style={{ fontFamily: mono, fontSize: 14, fontWeight: 600, letterSpacing: -0.3, fontVariantNumeric: "tabular-nums" }}>{fmtBRL(bucket.valor_pv)}</div>
          <div style={{ fontSize: 10.5, color: t.textFaint, marginTop: 1, letterSpacing: 0.3, textTransform: "uppercase" }}>previsão {bucket.previsao}</div>
        </div>
      </div>

      {/* Items as condensed rows */}
      <div>
        {bucket.items.map((it, i) => {
          const [bg, fg] = status[it.status];
          return (
            <div key={i} style={{ display: "grid", gridTemplateColumns: "70px 1fr 90px 110px 130px 110px", padding: "8px 16px", gap: 12, alignItems: "center", borderTop: i > 0 ? `1px solid ${t.border}` : "none", fontSize: 12.5 }}>
              <span style={{ fontFamily: mono, fontSize: 11, color: t.textMuted }}>{it.rc}</span>
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: t.text }}>{it.desc}</span>
              <span style={{ fontFamily: mono, fontSize: 11.5, textAlign: "right", color: t.textMuted, fontVariantNumeric: "tabular-nums" }}>{fmtNum(it.qtd)}× {fmtBRL(it.custo).replace("R$","").trim()}</span>
              <span style={{ fontFamily: mono, fontSize: 11.5, color: t.textFaint, fontVariantNumeric: "tabular-nums" }}>{it.pc || "—"}</span>
              <span style={{ color: t.textMuted, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontSize: 11.5 }}>{it.fornecedor || "—"}</span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 5, justifySelf: "end", padding: "2px 9px", borderRadius: 4, fontSize: 10.5, fontWeight: 600, background: bg, color: fg, letterSpacing: 0.4, textTransform: "uppercase" }}>
                {STATUS_META[it.status].short}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DPipeline({ stages, t }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 0 }}>
      {stages.map((s, i) => (
        <React.Fragment key={s.label}>
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, position: "relative" }}>
            <span style={{ width: 8, height: 8, borderRadius: 999, background: s.done ? t.accent : t.border, boxShadow: s.done ? `0 0 0 3px ${t.accentSoft}` : "none", zIndex: 1 }} />
            <span style={{ fontSize: 9.5, color: s.done ? t.text : t.textFaint, fontWeight: 600, letterSpacing: 0.5, textTransform: "uppercase" }}>{s.label}</span>
            <span style={{ fontSize: 9.5, color: t.textFaint }}>{s.detail}</span>
          </div>
          {i < stages.length - 1 && (
            <div style={{ flex: 0.4, height: 1, background: stages[i + 1].done ? t.accent : t.border, marginTop: -22 }} />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function DBold() {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", height: "100%" }}>
      <div style={{ position: "relative", overflow: "hidden", borderRight: "1px solid #e5e7eb" }}><DPane mode="light" /></div>
      <div style={{ position: "relative", overflow: "hidden" }}><DPane mode="dark" /></div>
    </div>
  );
}

window.DBold = DBold;
