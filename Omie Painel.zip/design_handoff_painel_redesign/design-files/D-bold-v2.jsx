// Variação D · v2 — deep dive
// Refina a aposta criativa: comando-K como header permanente, sidebar de
// módulo, cards de PV/OS com pipeline horizontal, status pill clicável com
// dropdown, células editáveis no estilo "ink underline" (sem amarelo tracejado),
// detail drawer ao clicar na linha, batch toolbar flutuante.

const D2_T = {
  light: {
    bg: "#f4f4f0", panel: "#ffffff", border: "#e3e3dc", borderStrong: "#c8c8be",
    text: "#0e0e0c", textMuted: "#5b5b54", textFaint: "#8e8e84",
    accent: "#0e6e57", accentSoft: "#dbeee5", ink: "#0e0e0c",
    rowHover: "#f9f9f5", editHi: "#fef9d6", editLine: "#cfb742",
    drawer: "#ffffff", drawerHead: "#f4f4f0",
  },
  dark: {
    bg: "#0a0a08", panel: "#141412", border: "#23231e", borderStrong: "#34342c",
    text: "#f1f1ea", textMuted: "#a8a89e", textFaint: "#6c6c61",
    accent: "#3eba9a", accentSoft: "#15302a", ink: "#f1f1ea",
    rowHover: "#1a1a16", editHi: "#3a3416", editLine: "#6e6024",
    drawer: "#141412", drawerHead: "#0e0e0c",
  },
};

const D2_STATUS = {
  light: {
    APROVADO: ["#0e6e57", "#fff"], APROVADO_FAT_DIRETO: ["#0e6493", "#fff"],
    PRE_SELECAO: ["#b8651a", "#fff"], PENDENTE: ["#1a1a18", "#fff"],
    NAO_APROVADO: ["#5223a4", "#fff"], REJEITADO_VALIDADE: ["#ede2ff", "#5223a4"],
    CANCELAR_PEDIDO: ["#b8253a", "#fff"], N_A: ["#e3e3dc", "#5b5b54"],
  },
  dark: {
    APROVADO: ["#3eba9a", "#0a1812"], APROVADO_FAT_DIRETO: ["#5cb6ed", "#0a1622"],
    PRE_SELECAO: ["#e8a04a", "#1a0e02"], PENDENTE: ["#f1f1ea", "#0a0a08"],
    NAO_APROVADO: ["#ad8af0", "#1a0e2c"], REJEITADO_VALIDADE: ["#2a1c45", "#c2a8e8"],
    CANCELAR_PEDIDO: ["#ed5f7a", "#280a10"], N_A: ["#23231e", "#a8a89e"],
  },
};

const STATUS_ORDER = ["APROVADO","APROVADO_FAT_DIRETO","PRE_SELECAO","PENDENTE","NAO_APROVADO","REJEITADO_VALIDADE","CANCELAR_PEDIDO","N_A"];

function D2Pane({ mode }) {
  const t = D2_T[mode];
  const status = D2_STATUS[mode];
  const summary = summarize();
  const fontStack = `"Inter", -apple-system, BlinkMacSystemFont, system-ui, sans-serif`;
  const monoStack = `"JetBrains Mono", "SF Mono", ui-monospace, monospace`;

  const [openBucket, setOpenBucket] = React.useState(0);
  const [drawerItem, setDrawerItem] = React.useState(null);
  const [statusPopover, setStatusPopover] = React.useState(null); // {row, col}
  const [selected, setSelected] = React.useState(new Set());
  const [editingCell, setEditingCell] = React.useState(null);

  const toggleSel = (id) => {
    const s = new Set(selected);
    s.has(id) ? s.delete(id) : s.add(id);
    setSelected(s);
  };

  return (
    <div style={{ background: t.bg, color: t.text, fontFamily: fontStack, fontSize: 13, lineHeight: 1.5, height: "100%", display: "flex", position: "relative", overflow: "hidden" }}>
      {/* Sidebar */}
      <aside style={{ width: 188, background: t.panel, borderRight: `1px solid ${t.border}`, padding: "16px 12px", display: "flex", flexDirection: "column", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 9, padding: "0 6px 16px" }}>
          <div style={{ width: 24, height: 24, borderRadius: 6, background: t.accent, display: "grid", placeItems: "center", color: mode === "light" ? "#fff" : "#0a1812", fontWeight: 700, fontSize: 12, fontFamily: monoStack, letterSpacing: -0.5 }}>WW</div>
          <div style={{ fontSize: 12.5, fontWeight: 600, letterSpacing: -0.2 }}>Waterworks</div>
        </div>
        <div style={{ fontSize: 10, fontWeight: 600, color: t.textFaint, padding: "0 6px 4px", letterSpacing: 0.6, textTransform: "uppercase" }}>Compras</div>
        <D2NavItem t={t} label="Vendas avulsas" count={37} active monoStack={monoStack} />
        <D2NavItem t={t} label="Projetos PJ" count={28} monoStack={monoStack} />
        <D2NavItem t={t} label="PCs standalone" count={12} monoStack={monoStack} />
        <div style={{ fontSize: 10, fontWeight: 600, color: t.textFaint, padding: "12px 6px 4px", letterSpacing: 0.6, textTransform: "uppercase" }}>Operação</div>
        <D2NavItem t={t} label="Logística" monoStack={monoStack} />
        <D2NavItem t={t} label="Fornecedores" monoStack={monoStack} />
        <D2NavItem t={t} label="Relatórios" monoStack={monoStack} />
        <div style={{ marginTop: "auto", padding: "8px 8px", fontSize: 10.5, color: t.textMuted, fontFamily: monoStack, lineHeight: 1.5 }}>
          <div style={{ color: t.text, display: "flex", alignItems: "center", gap: 5 }}>
            <span style={{ width: 5, height: 5, borderRadius: 999, background: t.accent }} />
            sync · 12m
          </div>
          <div style={{ color: t.textFaint, fontSize: 10 }}>Recebimento NF</div>
        </div>
      </aside>

      {/* Main */}
      <main style={{ flex: 1, display: "flex", flexDirection: "column", padding: "14px 18px", gap: 10, minWidth: 0, transition: "padding-right .25s" }}>
        {/* Top bar */}
        <div style={{ display: "flex", alignItems: "baseline", gap: 12 }}>
          <h1 style={{ margin: 0, fontSize: 18, fontWeight: 600, letterSpacing: -0.4 }}>Vendas avulsas</h1>
          <span style={{ fontSize: 11.5, color: t.textMuted, fontFamily: monoStack }}>1.783 itens · 32 PV/OS</span>
          <div style={{ flex: 1 }} />
          <span style={{ fontSize: 10.5, color: t.textFaint, fontFamily: monoStack, letterSpacing: 0.4, textTransform: "uppercase" }}>Comprador · edita PV/OS · RC · PC · Log</span>
        </div>

        {/* Hero command bar */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", background: t.panel, border: `1px solid ${t.border}`, borderRadius: 10, boxShadow: mode === "light" ? "0 1px 0 rgba(0,0,0,.03), 0 6px 20px -14px rgba(0,0,0,.1)" : "none" }}>
          <span style={{ fontFamily: monoStack, fontSize: 10, color: t.textFaint, letterSpacing: 1, textTransform: "uppercase", padding: "2px 6px", background: mode === "light" ? "#f4f4f0" : "#0a0a08", borderRadius: 4 }}>⌘K</span>
          <div style={{ width: 1, height: 14, background: t.border }} />
          <div style={{ flex: 1, fontSize: 13.5, color: t.textMuted }}>
            <span style={{ color: t.text, fontWeight: 500 }}>Aprovar</span>
            <span style={{ color: t.textFaint }}> · </span>
            <span>buscar PC, fornecedor "KSB", filtrar por pendentes…</span>
          </div>
          <span style={{ fontFamily: monoStack, fontSize: 10, color: t.textFaint }}>tab pra ações</span>
        </div>

        {/* KPI strip */}
        <div style={{ display: "flex", border: `1px solid ${t.border}`, borderRadius: 10, background: t.panel, overflow: "hidden" }}>
          {[
            { label: "Aprovados",     value: summary.aprov,    spark: [4,5,7,6,8,9,11,10,12,13], tone: status.APROVADO,     dotColor: mode === "light" ? "#0e6e57" : "#3eba9a" },
            { label: "Pendentes",     value: summary.pend,     spark: [9,8,10,7,8,9,7,6,8,7],   tone: status.PENDENTE,     dotColor: mode === "light" ? "#1a1a18" : "#f1f1ea" },
            { label: "Não aprovados", value: summary.naoAprov, spark: [2,3,2,4,3,2,3,4,3,3],   tone: status.NAO_APROVADO, dotColor: mode === "light" ? "#5223a4" : "#ad8af0" },
            { label: "Atrasados",     value: summary.atras,    spark: [1,2,2,3,3,4,4,3,4,4],   tone: status.PRE_SELECAO,  dotColor: mode === "light" ? "#b8651a" : "#e8a04a" },
            { label: "Sem projeto",   value: summary.semProj,  spark: [3,2,2,2,1,1,1,1,1,1],   tone: status.N_A,          dotColor: t.textFaint },
          ].map((k, i, arr) => (
            <div key={k.label} style={{ flex: 1, padding: "11px 14px", borderRight: i < arr.length - 1 ? `1px solid ${t.border}` : "none", display: "flex", flexDirection: "column", gap: 4, cursor: "pointer" }}>
              <div style={{ display: "flex", alignItems: "baseline", gap: 8, justifyContent: "space-between" }}>
                <div style={{ display: "flex", alignItems: "baseline", gap: 6 }}>
                  <span style={{ width: 6, height: 6, borderRadius: 999, background: k.dotColor, display: "inline-block", alignSelf: "center" }} />
                  <span style={{ fontSize: 22, fontWeight: 600, letterSpacing: -0.6, fontVariantNumeric: "tabular-nums", fontFamily: monoStack }}>{fmtNum(k.value)}</span>
                </div>
                <D2Spark data={k.spark} color={k.dotColor} />
              </div>
              <div style={{ fontSize: 11, color: t.textMuted, letterSpacing: 0.4, textTransform: "uppercase", fontWeight: 500 }}>{k.label}</div>
            </div>
          ))}
        </div>

        {/* Filter row */}
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          {["Todos · 1.783", "Aprovados · 24", "Pendentes · 13", "Atrasados · 4"].map((l, i) => (
            <button key={l} style={{ padding: "5px 11px", fontSize: 12, fontWeight: 500, border: `1px solid ${i === 0 ? t.borderStrong : t.border}`, background: i === 0 ? (mode === "light" ? "#0e0e0c" : "#f1f1ea") : t.panel, color: i === 0 ? (mode === "light" ? "#fff" : "#0a0a08") : t.textMuted, borderRadius: 6, cursor: "pointer" }}>{l}</button>
          ))}
          <div style={{ width: 1, height: 18, background: t.border, margin: "0 4px" }} />
          {["Projeto", "Tipo", "Etapa PC", "Categoria", "Fornecedor"].map(f => (
            <button key={f} style={{ padding: "5px 9px", fontSize: 12, border: `1px solid ${t.border}`, background: t.panel, color: t.textMuted, borderRadius: 6, cursor: "pointer", fontWeight: 500 }}>+ {f}</button>
          ))}
          <div style={{ flex: 1 }} />
          <span style={{ fontFamily: monoStack, fontSize: 10.5, color: t.textFaint }}>{selected.size > 0 ? `${selected.size} selecionados` : "·"}</span>
        </div>

        {/* Cards list */}
        <div style={{ flex: 1, overflow: "auto", display: "flex", flexDirection: "column", gap: 10, paddingBottom: 80 }}>
          {BUCKETS.slice(0, 4).map((b, idx) => (
            <D2Card key={b.pv_os} bucket={b} t={t} status={status} mono={monoStack} mode={mode}
              open={openBucket === idx}
              onToggle={() => setOpenBucket(openBucket === idx ? -1 : idx)}
              onRowClick={(it) => setDrawerItem({ ...it, pv_os: b.pv_os, cliente: b.cliente, projeto: b.projeto })}
              onStatusClick={(rowId, anchor) => setStatusPopover({ rowId, anchor })}
              selected={selected} toggleSel={toggleSel}
              editingCell={editingCell} setEditingCell={setEditingCell}
            />
          ))}
        </div>

        {/* Batch toolbar */}
        {selected.size > 0 && (
          <div style={{ position: "absolute", bottom: 18, left: "50%", transform: "translateX(-50%)", display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", background: mode === "light" ? "#0e0e0c" : "#f1f1ea", color: mode === "light" ? "#f1f1ea" : "#0a0a08", borderRadius: 10, boxShadow: "0 12px 32px rgba(0,0,0,.25)", fontFamily: fontStack, fontSize: 12.5, fontWeight: 500, zIndex: 30 }}>
            <span style={{ fontFamily: monoStack, fontSize: 11, opacity: 0.7 }}>{selected.size} selecionados</span>
            <div style={{ width: 1, height: 14, background: mode === "light" ? "#3a3a35" : "#c8c8be" }} />
            <button style={D2BatchBtn(true, mode)}>✓ Aprovar</button>
            <button style={D2BatchBtn(false, mode)}>Fat. Direto</button>
            <button style={D2BatchBtn(false, mode)}>✗ Rejeitar</button>
            <button onClick={() => setSelected(new Set())} style={{ background: "transparent", border: 0, color: "inherit", opacity: 0.6, fontSize: 14, cursor: "pointer", padding: "0 4px" }}>×</button>
          </div>
        )}
      </main>

      {/* Detail drawer */}
      {drawerItem && (
        <D2Drawer item={drawerItem} t={t} status={status} mode={mode} mono={monoStack} onClose={() => setDrawerItem(null)} />
      )}

      {/* Status popover */}
      {statusPopover && (
        <D2StatusPopover t={t} status={status} mode={mode} anchor={statusPopover.anchor} onClose={() => setStatusPopover(null)} />
      )}

      <div style={{ position: "absolute", top: 8, right: 12, fontSize: 10, color: t.textFaint, letterSpacing: 0.5, textTransform: "uppercase", fontWeight: 600, fontFamily: monoStack, zIndex: 5 }}>{mode}</div>
    </div>
  );
}

function D2BatchBtn(primary, mode) {
  return {
    padding: "5px 11px",
    fontSize: 12, fontWeight: 600,
    background: primary ? (mode === "light" ? "#3eba9a" : "#0e6e57") : "transparent",
    color: primary ? (mode === "light" ? "#0a1812" : "#dafce8") : "inherit",
    border: primary ? "0" : `1px solid ${mode === "light" ? "#3a3a35" : "#c8c8be"}`,
    borderRadius: 6, cursor: "pointer",
  };
}

function D2NavItem({ t, label, count, active, monoStack }) {
  const dark = t === D2_T.dark;
  return (
    <div style={{ display: "flex", alignItems: "center", padding: "5px 8px", borderRadius: 5, fontSize: 12.5, color: active ? t.text : t.textMuted, background: active ? (dark ? "#1c1c18" : "#ebebe4") : "transparent", fontWeight: active ? 600 : 400, cursor: "pointer", marginBottom: 1 }}>
      <span style={{ flex: 1 }}>{label}</span>
      {count != null && <span style={{ fontSize: 10.5, color: t.textFaint, fontFamily: monoStack, fontVariantNumeric: "tabular-nums" }}>{count}</span>}
    </div>
  );
}

function D2Spark({ data, color }) {
  const w = 56, h = 16;
  const max = Math.max(...data), min = Math.min(...data);
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / (max - min || 1)) * h}`).join(" ");
  return <svg width={w} height={h} style={{ display: "block" }}><polyline points={pts} fill="none" stroke={color} strokeWidth="1.4" strokeLinejoin="round" strokeLinecap="round" opacity="0.85" /></svg>;
}

function D2Card({ bucket, t, status, mono, mode, open, onToggle, onRowClick, onStatusClick, selected, toggleSel, editingCell, setEditingCell }) {
  const stages = [
    { label: "PV/OS",     done: true,                                                                        detail: bucket.pv_os },
    { label: "RC",        done: bucket.items.some(i => i.rc !== "—"),                                        detail: `${bucket.items.length} itens` },
    { label: "PC",        done: bucket.items.some(i => i.pc),                                                detail: `${bucket.items.filter(i => i.pc).length}/${bucket.items.length} emitidos` },
    { label: "Aprovação", done: bucket.items.some(i => i.status === "APROVADO" || i.status === "APROVADO_FAT_DIRETO"), detail: `${bucket.items.filter(i => i.status === "APROVADO" || i.status === "APROVADO_FAT_DIRETO").length} ok` },
    { label: "Logística", done: false,                                                                       detail: "aguardando" },
  ];
  return (
    <div style={{ background: t.panel, border: `1px solid ${t.border}`, borderRadius: 10, overflow: "hidden" }}>
      <div onClick={onToggle} style={{ padding: "12px 16px", display: "grid", gridTemplateColumns: "180px 1fr 150px 30px", gap: 16, alignItems: "center", borderBottom: open ? `1px solid ${t.border}` : "none", cursor: "pointer", background: mode === "light" ? "#fafaf6" : "#16161200" }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontFamily: mono, fontSize: 13, fontWeight: 600, letterSpacing: -0.2 }}>{bucket.pv_os}</span>
            <span style={{ fontSize: 9.5, color: t.textFaint, fontFamily: mono, padding: "1px 5px", border: `1px solid ${t.border}`, borderRadius: 3, letterSpacing: 0.5, textTransform: "uppercase" }}>{bucket.type}</span>
          </div>
          <div style={{ fontSize: 11.5, color: t.textMuted, marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{bucket.cliente}</div>
          <div style={{ fontSize: 10.5, color: t.textFaint, marginTop: 1, fontFamily: mono }}>{bucket.projeto}</div>
        </div>
        <D2Pipeline stages={stages} t={t} mono={mono} />
        <div style={{ textAlign: "right" }}>
          <div style={{ fontFamily: mono, fontSize: 14, fontWeight: 600, letterSpacing: -0.3, fontVariantNumeric: "tabular-nums" }}>{fmtBRL(bucket.valor_pv)}</div>
          <div style={{ fontSize: 10, color: t.textFaint, marginTop: 2, letterSpacing: 0.4, textTransform: "uppercase", fontFamily: mono }}>previsão {bucket.previsao}</div>
        </div>
        <span style={{ color: t.textFaint, textAlign: "center", fontSize: 12 }}>{open ? "▾" : "▸"}</span>
      </div>

      {open && (
        <div>
          {/* row header */}
          <div style={{ display: "grid", gridTemplateColumns: "32px 80px minmax(220px,1.4fr) 110px 110px 130px 110px 130px", gap: 10, padding: "6px 16px", fontSize: 9.5, fontWeight: 600, letterSpacing: 0.6, textTransform: "uppercase", color: t.textFaint, fontFamily: mono, background: mode === "light" ? "#f4f4f0" : "#0a0a08", borderBottom: `1px solid ${t.border}` }}>
            <span></span><span>RC</span><span>Descrição</span><span style={{ textAlign: "right" }}>Qtd × Custo</span><span style={{ textAlign: "right" }}>Total RC</span><span>Fornecedor</span><span>PC</span><span>Status</span>
          </div>
          {bucket.items.map((it, i) => {
            const id = `${bucket.pv_os}-${i}`;
            const checked = selected.has(id);
            return (
              <div key={i} onClick={() => onRowClick(it)} style={{ display: "grid", gridTemplateColumns: "32px 80px minmax(220px,1.4fr) 110px 110px 130px 110px 130px", gap: 10, padding: "8px 16px", alignItems: "center", borderTop: i > 0 ? `1px solid ${t.border}` : "none", fontSize: 12.5, cursor: "pointer", background: checked ? (mode === "light" ? "#f4faf7" : "#15302a30") : "transparent" }}
                onMouseEnter={(e) => e.currentTarget.style.background = checked ? (mode === "light" ? "#f4faf7" : "#15302a30") : t.rowHover}
                onMouseLeave={(e) => e.currentTarget.style.background = checked ? (mode === "light" ? "#f4faf7" : "#15302a30") : "transparent"}>
                <input type="checkbox" checked={checked} onChange={() => toggleSel(id)} onClick={e => e.stopPropagation()} style={{ accentColor: t.accent, cursor: "pointer" }} />
                <span style={{ fontFamily: mono, fontSize: 11.5, color: t.textMuted }} onClick={e => { e.stopPropagation(); setEditingCell(`${id}-rc`); }}>
                  <D2EditCell t={t} editing={editingCell === `${id}-rc`} onClose={() => setEditingCell(null)} value={it.rc} mono={mono} />
                </span>
                <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: t.text }}>{it.desc}</span>
                <span style={{ fontFamily: mono, fontSize: 11.5, textAlign: "right", color: t.textMuted, fontVariantNumeric: "tabular-nums" }}>{fmtNum(it.qtd)} × {fmtBRL(it.custo).replace("R$", "").trim()}</span>
                <span style={{ fontFamily: mono, fontSize: 11.5, textAlign: "right", color: t.text, fontWeight: 500, fontVariantNumeric: "tabular-nums" }}>{fmtBRL(it.qtd * it.custo)}</span>
                <span style={{ color: t.textMuted, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontSize: 11.5 }}>{it.fornecedor || "—"}</span>
                <span style={{ fontFamily: mono, fontSize: 11.5, color: t.textFaint, fontVariantNumeric: "tabular-nums" }} onClick={e => { e.stopPropagation(); setEditingCell(`${id}-pc`); }}>
                  <D2EditCell t={t} editing={editingCell === `${id}-pc`} onClose={() => setEditingCell(null)} value={it.pc || ""} placeholder="+ PC" mono={mono} />
                </span>
                <D2StatusPill it={it} status={status} mono={mono} onClick={(e) => { e.stopPropagation(); onStatusClick(id, e.currentTarget.getBoundingClientRect()); }} />
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function D2EditCell({ t, editing, onClose, value, placeholder, mono }) {
  if (editing) {
    return (
      <input autoFocus defaultValue={value} placeholder={placeholder} onBlur={onClose} onKeyDown={e => e.key === "Enter" && onClose()}
        style={{ background: t.editHi, border: 0, borderBottom: `1.5px solid ${t.editLine}`, padding: "1px 4px", fontFamily: mono, fontSize: 11.5, color: t.text, outline: 0, width: 80, fontVariantNumeric: "tabular-nums" }}
      />
    );
  }
  if (!value) return <span style={{ color: t.textFaint, borderBottom: `1px dashed ${t.border}`, padding: "0 2px" }}>{placeholder || "—"}</span>;
  return <span style={{ borderBottom: `1px dashed ${t.border}`, padding: "0 2px" }}>{value}</span>;
}

function D2StatusPill({ it, status, mono, onClick }) {
  const [bg, fg] = status[it.status];
  return (
    <button onClick={onClick} style={{ display: "inline-flex", alignItems: "center", gap: 5, justifySelf: "start", padding: "3px 9px", borderRadius: 4, fontSize: 10.5, fontWeight: 600, background: bg, color: fg, letterSpacing: 0.4, textTransform: "uppercase", border: 0, cursor: "pointer", fontFamily: mono }}>
      {STATUS_META[it.status].short}
      <span style={{ opacity: 0.5, fontSize: 9 }}>▾</span>
    </button>
  );
}

function D2Pipeline({ stages, t, mono }) {
  return (
    <div style={{ display: "flex", alignItems: "flex-start", gap: 0 }}>
      {stages.map((s, i) => (
        <React.Fragment key={s.label}>
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 2, position: "relative", minWidth: 0 }}>
            <span style={{ width: 9, height: 9, borderRadius: 999, background: s.done ? t.accent : t.panel, border: s.done ? "none" : `1.5px solid ${t.borderStrong}`, boxShadow: s.done ? `0 0 0 3px ${t.accentSoft}` : "none", zIndex: 1 }} />
            <span style={{ fontSize: 9.5, color: s.done ? t.text : t.textFaint, fontWeight: 600, letterSpacing: 0.5, textTransform: "uppercase", marginTop: 4, fontFamily: mono }}>{s.label}</span>
            <span style={{ fontSize: 9.5, color: t.textFaint, textAlign: "center", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: "100%", padding: "0 2px" }}>{s.detail}</span>
          </div>
          {i < stages.length - 1 && (
            <div style={{ width: 24, height: 1.5, background: stages[i + 1].done ? t.accent : t.border, marginTop: 4 }} />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function D2StatusPopover({ t, status, mode, anchor, onClose }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    setTimeout(() => document.addEventListener("mousedown", onDoc), 0);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [onClose]);
  // anchor coords are viewport-relative; clamp inside the pane.
  const top = Math.min(anchor.bottom + 4, window.innerHeight - 360);
  const left = Math.max(8, Math.min(anchor.left, window.innerWidth - 240));
  return ReactDOM.createPortal(
    <div ref={ref} style={{ position: "fixed", top, left, width: 230, background: t.panel, border: `1px solid ${t.borderStrong}`, borderRadius: 10, padding: 6, boxShadow: "0 14px 40px rgba(0,0,0,.18), 0 0 0 1px rgba(0,0,0,.04)", zIndex: 9999, fontFamily: '"Inter", system-ui, sans-serif' }}>
      <div style={{ fontSize: 10, color: t.textFaint, padding: "4px 8px 6px", letterSpacing: 0.6, textTransform: "uppercase", fontWeight: 600 }}>Alterar status</div>
      {STATUS_ORDER.map(code => {
        const [bg, fg] = status[code];
        return (
          <button key={code} style={{ width: "100%", display: "flex", alignItems: "center", padding: "5px 6px", borderRadius: 6, background: "transparent", border: 0, cursor: "pointer", textAlign: "left", marginBottom: 1, color: t.text, fontSize: 12.5 }}
            onMouseEnter={e => e.currentTarget.style.background = mode === "light" ? "#f4f4f0" : "#1a1a16"}
            onMouseLeave={e => e.currentTarget.style.background = "transparent"}
            onClick={onClose}>
            <span style={{ display: "inline-flex", padding: "2px 8px", borderRadius: 4, fontSize: 10, fontWeight: 600, background: bg, color: fg, letterSpacing: 0.4, textTransform: "uppercase", fontFamily: '"JetBrains Mono", monospace' }}>{STATUS_META[code].short}</span>
            <span style={{ flex: 1 }} />
          </button>
        );
      })}
    </div>,
    document.body
  );
}

function D2Drawer({ item, t, status, mode, mono, onClose }) {
  const [bg, fg] = status[item.status];
  return (
    <div style={{ width: 380, background: t.drawer, borderLeft: `1px solid ${t.border}`, display: "flex", flexDirection: "column", flexShrink: 0, overflow: "auto", boxShadow: "-12px 0 40px -20px rgba(0,0,0,.15)" }}>
      <div style={{ padding: "14px 16px", borderBottom: `1px solid ${t.border}`, background: t.drawerHead, display: "flex", alignItems: "center", gap: 10, position: "sticky", top: 0, zIndex: 1 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: mono, fontSize: 11, color: t.textFaint, letterSpacing: 0.4, textTransform: "uppercase" }}>{item.pv_os} · {item.rc}</div>
          <div style={{ fontSize: 14, fontWeight: 600, marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.desc}</div>
        </div>
        <button onClick={onClose} style={{ background: "transparent", border: 0, color: t.textMuted, cursor: "pointer", fontSize: 18, padding: "0 4px" }}>×</button>
      </div>

      <div style={{ padding: "14px 16px", borderBottom: `1px solid ${t.border}`, display: "flex", flexDirection: "column", gap: 10 }}>
        <span style={{ display: "inline-flex", alignSelf: "flex-start", padding: "4px 11px", borderRadius: 4, fontSize: 10.5, fontWeight: 600, background: bg, color: fg, letterSpacing: 0.4, textTransform: "uppercase", fontFamily: mono }}>{STATUS_META[item.status].label}</span>
        <D2Field t={t} mono={mono} label="Cliente"     value={item.cliente} />
        <D2Field t={t} mono={mono} label="Projeto"     value={item.projeto} />
        <D2Field t={t} mono={mono} label="Fornecedor"  value={item.fornecedor || "— a definir —"} />
        <D2Field t={t} mono={mono} label="Etapa PC"    value={item.etapa} />
      </div>

      <div style={{ padding: "14px 16px", borderBottom: `1px solid ${t.border}`, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        <D2Field t={t} mono={mono} label="Qtd"        value={fmtNum(item.qtd)} mono2 />
        <D2Field t={t} mono={mono} label="Custo unit" value={fmtBRL(item.custo)} mono2 />
        <D2Field t={t} mono={mono} label="Total RC"   value={fmtBRL(item.qtd * item.custo)} mono2 highlight />
        <D2Field t={t} mono={mono} label="Valor PC"   value={fmtBRL(item.valor_pc)} mono2 />
      </div>

      <div style={{ padding: "14px 16px", borderBottom: `1px solid ${t.border}` }}>
        <div style={{ fontSize: 10.5, fontWeight: 600, color: t.textFaint, letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 8 }}>Atividade</div>
        {[
          { who: "ana.silva", when: "27/04 09:32", what: "alterou status para Aprovado" },
          { who: "marco.t",   when: "26/04 14:11", what: "atribuiu fornecedor KSB Pumps" },
          { who: "sistema",   when: "25/04 18:00", what: "PC criado no Omie" },
        ].map((a, i) => (
          <div key={i} style={{ display: "flex", gap: 8, padding: "6px 0", borderBottom: i < 2 ? `1px solid ${t.border}` : "none" }}>
            <div style={{ width: 22, height: 22, borderRadius: 999, background: t.accentSoft, color: t.accent, fontSize: 10, fontWeight: 700, display: "grid", placeItems: "center", flexShrink: 0, fontFamily: mono }}>{a.who.slice(0, 2).toUpperCase()}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, color: t.text }}><span style={{ fontWeight: 500 }}>{a.who}</span> {a.what}</div>
              <div style={{ fontSize: 10.5, color: t.textFaint, fontFamily: mono }}>{a.when}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ padding: "14px 16px", marginTop: "auto", display: "flex", gap: 6 }}>
        <button style={{ flex: 1, padding: "8px 12px", background: t.accent, color: mode === "light" ? "#fff" : "#0a1812", border: 0, borderRadius: 7, fontSize: 12.5, fontWeight: 600, cursor: "pointer" }}>✓ Aprovar</button>
        <button style={{ flex: 1, padding: "8px 12px", background: "transparent", color: t.text, border: `1px solid ${t.borderStrong}`, borderRadius: 7, fontSize: 12.5, fontWeight: 500, cursor: "pointer" }}>Editar</button>
      </div>
    </div>
  );
}

function D2Field({ t, mono, label, value, mono2, highlight }) {
  return (
    <div>
      <div style={{ fontSize: 10, color: t.textFaint, letterSpacing: 0.5, textTransform: "uppercase", fontWeight: 600, marginBottom: 2 }}>{label}</div>
      <div style={{ fontSize: 12.5, color: highlight ? t.accent : t.text, fontFamily: mono2 ? mono : "inherit", fontWeight: highlight ? 600 : 400, fontVariantNumeric: "tabular-nums" }}>{value}</div>
    </div>
  );
}

function DBoldV2() {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", height: "100%" }}>
      <div style={{ position: "relative", overflow: "hidden", borderRight: "1px solid #e5e7eb" }}><D2Pane mode="light" /></div>
      <div style={{ position: "relative", overflow: "hidden" }}><D2Pane mode="dark" /></div>
    </div>
  );
}

window.DBoldV2 = DBoldV2;
