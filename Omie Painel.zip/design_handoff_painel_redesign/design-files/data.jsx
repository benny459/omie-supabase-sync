// Shared mock data for the Painel Waterworks redesign explorations.
// Sticks to the real schema from the bundle: PV/OS buckets, status enum,
// 6 column groups. Numbers/clients/projects are fabricated but plausibly BR.

const STATUS_META = {
  APROVADO:            { label: "Aprovado",                 short: "Aprov." },
  APROVADO_FAT_DIRETO: { label: "Aprovado · Fat. Direto",   short: "Fat. Direto" },
  PRE_SELECAO:         { label: "Pré seleção",              short: "Pré sel." },
  PENDENTE:            { label: "Pendente",                 short: "Pendente" },
  NAO_APROVADO:        { label: "Não aprovado",             short: "Não aprov." },
  REJEITADO_VALIDADE:  { label: "Rejeitado por validade",   short: "Validade" },
  CANCELAR_PEDIDO:     { label: "Cancelar pedido",          short: "Cancelar" },
  N_A:                 { label: "N/A",                      short: "N/A" },
};

// Status tone tokens: each variation styles them differently, so we expose
// raw HSL anchors instead of bg-* classes. Keeps the spirit of the original
// palette (emerald/sky/orange/slate/violet/rose) but tunable per skin.
const STATUS_TONES = {
  APROVADO:            { hue: 152, sat: 60, key: "emerald" },
  APROVADO_FAT_DIRETO: { hue: 200, sat: 80, key: "sky" },
  PRE_SELECAO:         { hue: 28,  sat: 90, key: "orange" },
  PENDENTE:            { hue: 220, sat: 12, key: "slate" },
  NAO_APROVADO:        { hue: 268, sat: 55, key: "violet" },
  REJEITADO_VALIDADE:  { hue: 268, sat: 35, key: "violet-soft" },
  CANCELAR_PEDIDO:     { hue: 350, sat: 75, key: "rose" },
  N_A:                 { hue: 220, sat: 8,  key: "slate-soft" },
};

const GROUPS = [
  { key: "pvos",      label: "PV/OS · Omie",         hue: 268 }, // violet
  { key: "rc",        label: "RC · Requisição",      hue: 38  }, // amber
  { key: "pc",        label: "PC · Omie",            hue: 215 }, // blue
  { key: "aprovacao", label: "Aprovação",            hue: 152 }, // emerald
  { key: "log",       label: "Logística",            hue: 188 }, // cyan
  { key: "extras",    label: "Fórmulas & Meta",      hue: 220 }, // slate
];

// Buckets: each PV/OS row groups N item rows. We mock 6 buckets for a tidy
// dashboard view; the real app shows ~30-50 visible at a time but the design
// language we want to communicate fits in fewer.
const BUCKETS = [
  {
    pv_os: "OS 4389",
    type: "OS",
    cliente: "Lubrasil Lubrificantes Ltda",
    projeto: "40_VS · Refinaria Paulínia",
    emissao: "17/04/2026",
    previsao: "06/05/2026",
    valor_pv: 95448.67,
    etapa: "Em produção",
    items: [
      { rc: "RC-2811", desc: "Válvula esfera 2\" inox 316",      qtd: 12, custo: 2480, pc: "PC-9912", fornecedor: "Hidrosul Equip.",   etapa: "PC emitido",    status: "APROVADO",            valor_pc: 29760, prev_pc: "28/04/2026" },
      { rc: "RC-2812", desc: "Conexão flange DN50",              qtd: 24, custo: 184,  pc: "PC-9913", fornecedor: "Mecan Componentes", etapa: "PC emitido",    status: "APROVADO",            valor_pc: 4416,  prev_pc: "30/04/2026" },
      { rc: "RC-2813", desc: "Atuador pneumático duplo",         qtd: 4,  custo: 6750, pc: "PC-9914", fornecedor: "Festo Brasil",      etapa: "Em cotação",    status: "APROVADO_FAT_DIRETO", valor_pc: 27000, prev_pc: "02/05/2026" },
      { rc: "RC-2814", desc: "Selo mecânico CR-1",               qtd: 8,  custo: 1240, pc: "PC-9915", fornecedor: "John Crane",        etapa: "Aguard. NF",    status: "PENDENTE",            valor_pc: 9920,  prev_pc: "05/05/2026" },
    ],
  },
  {
    pv_os: "OS 3483",
    type: "OS",
    cliente: "Ameneg Engenharia",
    projeto: "40_VS · CETESB",
    emissao: "21/02/2025",
    previsao: "22/05/2025",
    valor_pv: 16284.00,
    etapa: "Aguardando faturamento",
    items: [
      { rc: "RC-2614", desc: "Bomba centrífuga horizontal 5cv",  qtd: 2,  custo: 4180, pc: "PC-9712", fornecedor: "KSB Pumps",         etapa: "Recebido",      status: "APROVADO",            valor_pc: 8360,  prev_pc: "10/03/2025" },
      { rc: "RC-2615", desc: "Tubulação PEAD 110mm · 6m",         qtd: 18, custo: 312,  pc: "PC-9713", fornecedor: "Tigre",             etapa: "Recebido",      status: "APROVADO",            valor_pc: 5616,  prev_pc: "12/03/2025" },
      { rc: "RC-2616", desc: "Filtro Y inox · DN80",              qtd: 3,  custo: 760,  pc: null,      fornecedor: null,                etapa: "Sem PC",        status: "PRE_SELECAO",         valor_pc: 0,     prev_pc: null },
    ],
  },
  {
    pv_os: "PV 1715",
    type: "PV",
    cliente: "Hospital A.C. Camargo",
    projeto: "41_VP · Reforma Bloco C",
    emissao: "17/04/2026",
    previsao: "07/05/2026",
    valor_pv: 13335.00,
    etapa: "Em produção",
    items: [
      { rc: "RC-2901", desc: "Sensor de pressão 4-20mA",          qtd: 6,  custo: 890,  pc: "PC-9988", fornecedor: "Endress+Hauser",    etapa: "Em cotação",    status: "PRE_SELECAO",         valor_pc: 5340,  prev_pc: "30/04/2026" },
      { rc: "RC-2902", desc: "Painel de comando IP65",            qtd: 1,  custo: 4200, pc: "PC-9989", fornecedor: "WEG Automação",     etapa: "PC emitido",    status: "APROVADO",            valor_pc: 4200,  prev_pc: "01/05/2026" },
      { rc: "RC-2903", desc: "Disjuntor tripolar 100A",           qtd: 3,  custo: 280,  pc: null,      fornecedor: null,                etapa: "Sem PC",        status: "NAO_APROVADO",        valor_pc: 0,     prev_pc: null },
    ],
  },
  {
    pv_os: "OS 3484",
    type: "OS",
    cliente: "CNTT Logística",
    projeto: "40_VS · Hub Cajamar",
    emissao: "24/02/2025",
    previsao: "22/05/2025",
    valor_pv: 16182.00,
    etapa: "Faturado parcialmente",
    items: [
      { rc: "RC-2701", desc: "Mancal de rolamento SKF 6308",      qtd: 14, custo: 320,  pc: "PC-9821", fornecedor: "SKF do Brasil",     etapa: "Recebido",      status: "APROVADO",            valor_pc: 4480,  prev_pc: "10/03/2025" },
      { rc: "RC-2702", desc: "Acoplamento elástico tipo grade",   qtd: 4,  custo: 1180, pc: "PC-9822", fornecedor: "Falk-Rexnord",      etapa: "Em trânsito",   status: "APROVADO_FAT_DIRETO", valor_pc: 4720,  prev_pc: "12/03/2025" },
      { rc: "RC-2703", desc: "Correia em V tipo B-71",            qtd: 30, custo: 42,   pc: "PC-9823", fornecedor: "Gates Brasil",      etapa: "Aguard. NF",    status: "PENDENTE",            valor_pc: 1260,  prev_pc: "15/03/2025" },
    ],
  },
  {
    pv_os: "PV 1370",
    type: "PV",
    cliente: "Forneria & Enoteca Midi",
    projeto: "41_VP · Cozinha industrial",
    emissao: "04/12/2024",
    previsao: "12/12/2024",
    valor_pv: 12113.30,
    etapa: "Encerrado",
    items: [
      { rc: "RC-2401", desc: "Trocador de calor a placas",        qtd: 1,  custo: 8400, pc: "PC-9512", fornecedor: "Alfa Laval",        etapa: "Recebido",      status: "REJEITADO_VALIDADE",  valor_pc: 8400,  prev_pc: "08/12/2024" },
      { rc: "RC-2402", desc: "Válvula reguladora vapor",          qtd: 2,  custo: 1680, pc: "PC-9513", fornecedor: "Spirax Sarco",      etapa: "Recebido",      status: "CANCELAR_PEDIDO",     valor_pc: 3360,  prev_pc: "10/12/2024" },
    ],
  },
  {
    pv_os: "PV 1713",
    type: "PV",
    cliente: "HCor · Hospital do Coração",
    projeto: "41_VP · Central de utilidades",
    emissao: "17/04/2026",
    previsao: "06/05/2026",
    valor_pv: 9417.24,
    etapa: "Aguardando RC",
    items: [
      { rc: "—",       desc: "—",                                  qtd: 0,  custo: 0,    pc: null,      fornecedor: null,                etapa: "—",             status: "N_A",                 valor_pc: 0,     prev_pc: null },
    ],
  },
];

// KPI summary derived from buckets — counts of unique items by status group.
function summarize() {
  let total = 0, aprov = 0, naoAprov = 0, pend = 0, atras = 0;
  for (const b of BUCKETS) for (const it of b.items) {
    total++;
    if (it.status === "APROVADO" || it.status === "APROVADO_FAT_DIRETO") aprov++;
    else if (it.status === "NAO_APROVADO" || it.status === "REJEITADO_VALIDADE" || it.status === "CANCELAR_PEDIDO") naoAprov++;
    else if (it.status === "PENDENTE" || it.status === "PRE_SELECAO") pend++;
  }
  // mock atrasados — items past previsao
  atras = 4;
  return { total, aprov, naoAprov, pend, atras, semProj: 1 };
}

// Currency formatter — pt-BR.
const fmtBRL = (v) =>
  v == null ? "—" :
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const fmtNum = (v) =>
  v == null ? "—" : v.toLocaleString("pt-BR");

Object.assign(window, {
  STATUS_META, STATUS_TONES, GROUPS, BUCKETS,
  summarize, fmtBRL, fmtNum,
});
