# Handoff: Painel Waterworks · Redesign (Variação D — "Bold ⌘K")

## Overview

Redesenho da página principal do **Painel Waterworks** (`/avulsos`, `/projetos`, `/pcs`) — app B2B interno de aprovação de Pedidos de Compra (PCs) usado por ~20 pessoas o dia inteiro.

A direção escolhida (**Variação D**) reposiciona o produto como uma "ferramenta de poder" no espírito de Linear / Stripe / Attio: comando-K como header permanente, sidebar unificada para os 3 módulos, **cards de PV/OS** com **pipeline horizontal** (PV → RC → PC → Aprovação → Logística) substituindo a tabela única atual, status pills clicáveis com popover, batch toolbar flutuante, detail drawer ao clicar numa linha, e células editáveis no estilo "ink underline" tracejado em vez do amarelo cheio.

Mantém integralmente: **8 status pills**, **6 grupos de colunas** (PV/OS · RC · PC · Aprovação · Logística · Fórmulas), schema Omie/Supabase.

## About the Design Files

Os arquivos em `design-files/` são **referências de design criadas em HTML** — protótipos React + JSX inline mostrando o look intended e o comportamento, não código de produção pra copiar.

A tarefa é **recriar esses designs HTML no codebase existente** (Next.js 16 App Router + React 19 + Tailwind 3 + TypeScript) usando os padrões já estabelecidos: `app/(app)/<page>/page.tsx`, componentes em `components/`, helpers em `lib/`, Supabase server-side, etc. Os arquivos de mock usam estilos inline pra fidelidade visual rápida — na implementação use **classes Tailwind** conforme convenção do projeto.

## Fidelity

**Alta fidelidade (hi-fi).** Cores, tipografia, espaçamentos e interações estão decididos. O dev deve recriar pixel-perfect dentro do que o Tailwind permite (use os tokens já configurados, estenda quando necessário). Comportamentos de drawer, popover e batch toolbar estão desenhados em código React funcional.

## Screens / Views

### 1. Página principal (`/avulsos`, `/projetos`, `/pcs` — mesmo layout)

**Layout geral**: grid de 2 colunas — sidebar fixa **188px** + main flex.

#### Sidebar (188px, full-height)

- Background `panel` (branco/`#141412`), borda direita `border` (`#e3e3dc` / `#23231e`)
- Padding `16px 12px`
- Logo + nome no topo:
  - Quadrado **24×24**, `border-radius: 6px`, fundo `accent` (`#0e6e57` light / `#3eba9a` dark), iniciais "WW" em mono 12px branco
  - Nome "Waterworks" 12.5px / 600
- Seções com header **uppercase 10px / 600 / letter-spacing 0.6** color `textFaint`
  - **Compras**: Vendas avulsas (active, count 37), Projetos PJ (28), PCs standalone (12)
  - **Operação**: Logística, Fornecedores, Relatórios
- Item ativo: bg `#ebebe4` light / `#1c1c18` dark, fontWeight 600
- Hover: bg `rowHover`
- Counts em mono 10.5px alinhados à direita
- Footer: indicador de sync ("● sync · 12m" + "Recebimento NF") em mono 10.5px

#### Main (flex 1, padding `14px 18px`, gap 10px entre blocos)

##### Top bar (linha 1)
- `<h1>` "Vendas avulsas" 18px / 600 / letter-spacing -0.4
- "1.783 itens · 32 PV/OS" em mono 11.5px `textMuted`
- Spacer
- "Comprador · edita PV/OS · RC · PC · Log" mono 10.5px uppercase `textFaint` (badge de permissão)

##### Hero command bar (linha 2)
- Card 100% width, `border-radius: 10px`, padding `10px 12px`, border `border`, bg `panel`
- Sombra light: `0 1px 0 rgba(0,0,0,.03), 0 6px 20px -14px rgba(0,0,0,.1)` · sem sombra no dark
- Conteúdo:
  - Badge "⌘K" mono 10px uppercase, bg `bg`, padding `2px 6px`, radius 4
  - Divisor vertical 1×14 `border`
  - Texto: **"Aprovar"** 13.5px / 500 + " · buscar PC, fornecedor "KSB", filtrar por pendentes…" em `textMuted`
  - Direita: "tab pra ações" mono 10px `textFaint`
- Clique abre overlay ⌘K (a especificar — escopo de fase 2)

##### KPI strip (linha 3)
- Container: border `border`, radius 10, bg `panel`, overflow hidden, display flex
- 5 colunas com divisores `1px solid border` entre elas:
  - Aprovados (verde), Pendentes (preto), Não aprovados (violet), Atrasados (laranja), Sem projeto (cinza)
- Cada KPI:
  - Padding `11px 14px`, flex column gap 4
  - Header: dot 6×6 `dotColor` + número 22px / 600 / mono / tabular-nums + sparkline 56×16 à direita (polyline, stroke 1.4, opacity 0.85)
  - Label uppercase 11px / 500 / letter-spacing 0.4 `textMuted`
- Cursor pointer em cada — clique filtra a lista
- Sparkline data: array de 10 pontos (mockado por enquanto, derivar da histórica real)

##### Filter row (linha 4)
- Display flex gap 6
- 4 chips de status: "Todos · 1.783" (active), "Aprovados · 24", "Pendentes · 13", "Atrasados · 4"
  - Active: bg `#0e0e0c` (light) / `#f1f1ea` (dark), fg invertido, border `borderStrong`
  - Inactive: bg `panel`, color `textMuted`, border `border`
  - Padding `5px 11px`, fontSize 12 / 500, radius 6
- Divisor vertical
- 5 facets: "+ Projeto", "+ Tipo", "+ Etapa PC", "+ Categoria", "+ Fornecedor"
  - Mesmo estilo dos chips inativos, indicam que abrem dropdown de seleção
- Spacer
- Direita: indicador "{N} selecionados" ou "·" em mono 10.5px `textFaint`

##### Cards list (linha 5, flex 1, scroll)
- Display flex column gap 10
- Padding-bottom 80px (pra batch toolbar não cobrir último card)

#### Card de PV/OS (componente principal)

- Container: bg `panel`, border `border`, radius 10, overflow hidden

**Header do card** (sempre visível, clique colapsa/expande):
- Padding `12px 16px`
- Grid: `180px 1fr 150px 30px` gap 16
- Bg light: `#fafaf6` · dark: transparente (`#16161200`)
- Borda inferior `1px solid border` quando aberto
- Coluna 1 (180px): identidade do PV/OS
  - Linha 1: número (mono 13/600/-0.2) + tag "PV"/"OS" (badge mono 9.5px uppercase, padding `1px 5px`, border 1px `border`, radius 3)
  - Linha 2: cliente (11.5px `textMuted`, ellipsis)
  - Linha 3: projeto (mono 10.5px `textFaint`)
- Coluna 2 (1fr): **Pipeline horizontal** (componente abaixo)
- Coluna 3 (150px, text-align right):
  - Valor PV (mono 14/600/-0.3 tabular-nums)
  - "previsão {data}" mono 10px uppercase letter-spacing 0.4 `textFaint`
- Coluna 4 (30px): chevron `▾`/`▸` `textFaint` 12px

**Pipeline (componente)**:
- 5 stages (PV/OS, RC, PC, Aprovação, Logística), cada um com `done: bool` e `detail: string`
- Display flex align-items flex-start
- Cada stage: flex 1, column align center gap 2
  - Dot 9×9: bg `accent` se done com glow `0 0 0 3px accentSoft` · senão bg `panel` border 1.5px `borderStrong`
  - Label uppercase mono 9.5/600/letter-spacing 0.5 (color `text` se done, `textFaint` senão)
  - Detail 9.5px `textFaint` (ellipsis, max-width 100%)
- Conector entre stages: 24×1.5px, bg `accent` se próximo é done, senão `border`. margin-top 4px (alinha com dot)

**Body do card** (visível quando aberto):
- Row de header de colunas: grid `32px 80px minmax(220px,1.4fr) 110px 110px 130px 110px 130px` gap 10, padding `6px 16px`
  - Colunas: vazio · RC · DESCRIÇÃO · QTD × CUSTO · TOTAL RC · FORNECEDOR · PC · STATUS
  - Estilo: mono 9.5px / 600 / uppercase / letter-spacing 0.6 `textFaint`
  - Bg `bg` (`#f4f4f0` / `#0a0a08`), borda inferior `border`

- Row de item (cada RC): mesmo grid
  - Padding `8px 16px`, fontSize 12.5
  - Borda superior `border` (não na primeira)
  - Cursor pointer (clique abre drawer)
  - Hover: bg `rowHover`
  - Selected: bg `#f4faf7` (light) / `#15302a30` (dark) — sobrescreve hover
  - Conteúdo:
    1. Checkbox (accent-color `accent`)
    2. RC numero — célula editável (mono 11.5px `textMuted`)
    3. Descrição (truncada, `text`)
    4. "Qtd × Custo" mono 11.5px tabular-nums right-align `textMuted`
    5. Total RC (qtd × custo, calculado) mono 11.5px / 500 right-align `text`
    6. Fornecedor (truncado 11.5px `textMuted`)
    7. PC# — célula editável (mono 11.5px `textFaint`)
    8. Status pill (componente abaixo)

#### Status pill (clicável)

- Display inline-flex align center gap 5, padding `3px 9px`, radius 4
- fontSize 10.5 / 600 / letter-spacing 0.4 / uppercase / mono
- 8 variações de cor (ver "Design Tokens > Status colors" abaixo)
- Sufixo `▾` opacity 0.5 fontSize 9
- Clique abre **status popover** ancorado na pill via `getBoundingClientRect()`

#### Status popover (portal)

- Posição: `position: fixed`, `top: anchor.bottom + 4`, `left: clamp(8, anchor.left, viewport - 240)`
- Container: 230px width, bg `panel`, border 1px `borderStrong`, radius 10, padding 6, sombra `0 14px 40px rgba(0,0,0,.18), 0 0 0 1px rgba(0,0,0,.04)`
- Header: "Alterar status" 10px / 600 / uppercase / letter-spacing 0.6 `textFaint`, padding `4px 8px 6px`
- 8 botões (1 por status, na ordem do enum):
  - Width 100%, display flex align center, padding `5px 6px`, radius 6
  - Bg transparent → hover bg `bg`
  - Mostra a pill pequena à esquerda + label completa
- Click outside fecha (mousedown handler com setTimeout 0 pra não conflitar com a abertura)

#### Cell editáveis

- **Estado idle**: texto com `border-bottom: 1px dashed border`, padding `0 2px`. Color `textFaint` se vazio, mostra placeholder
- **Estado editing** (clicado): `<input>` autoFocus
  - Bg `editHi` (`#fef9d6` light / `#3a3416` dark)
  - Sem borda lateral, `border-bottom: 1.5px solid editLine` (`#cfb742` / `#6e6024`)
  - Padding `1px 4px`, fontSize 11.5, mono
  - onBlur ou Enter fecha → salva via Supabase + `router.refresh()` (mantém comportamento atual)

#### Batch toolbar (flutuante)

- Aparece quando `selected.size > 0`
- Posição: absolute bottom 18, left 50%, translateX -50%, z-index 30
- Container: bg `#0e0e0c` (light) / `#f1f1ea` (dark), color invertido
  - Padding `8px 12px`, radius 10, sombra `0 12px 32px rgba(0,0,0,.25)`
  - Display flex align center gap 8
- Conteúdo:
  - "{N} selecionados" mono 11px opacity 0.7
  - Divisor 1×14
  - Botão **✓ Aprovar** (primário): bg `accent`, padding `5px 11px`, fontSize 12 / 600, radius 6
  - Botão "Fat. Direto" (secundário): bg transparent, border 1px `#3a3a35`/`#c8c8be`
  - Botão "✗ Rejeitar" (idem secundário)
  - Botão fechar `×` (transparent, opacity 0.6)

#### Detail drawer (lateral direita)

- Aparece deslizando da direita ao clicar numa row
- Width 380px, full-height, bg `drawer`, border-left 1px `border`
- Sombra `-12px 0 40px -20px rgba(0,0,0,.15)`
- Display flex column, scroll vertical

**Header do drawer** (sticky top, padding `14px 16px`, border-bottom `border`, bg `drawerHead`):
- Esquerda: "PV-1715 · RC-2901" mono 11px uppercase letter-spacing 0.4 `textFaint`
  - Logo abaixo: descrição completa do item 14px / 600 (ellipsis)
- Direita: botão `×` (background transparent, fontSize 18, color `textMuted`)

**Bloco status + meta** (padding `14px 16px`, border-bottom `border`):
- Pill grande do status atual (label completo, padding `4px 11px`)
- 4 fields:
  - **Cliente**: nome completo
  - **Projeto**: ex "41_VP · Reforma Bloco C"
  - **Fornecedor**: ou "— a definir —" se null
  - **Etapa PC**: ex "PC emitido", "Em cotação"

**Bloco valores** (padding `14px 16px`, border-bottom, grid 2-col gap 10):
- Qtd (mono)
- Custo unit (mono)
- Total RC (mono, **highlight** color `accent` / 600)
- Valor PC (mono)

**Bloco atividade** (padding `14px 16px`, border-bottom):
- Header "Atividade" 10.5px / 600 / uppercase / letter-spacing 0.5 `textFaint`
- Lista de eventos (mock 3 itens):
  - Avatar 22×22 round, bg `accentSoft`, color `accent`, iniciais 10px / 700 mono
  - Nome (12 / 500) + ação (12)
  - Timestamp mono 10.5px `textFaint`
  - Borda inferior `border` (exceto último)
- **Backend**: ler de tabela de auditoria existente (Supabase) — query por (modulo, row_id), order by created_at desc, limit 20

**Footer do drawer** (margin-top auto, padding `14px 16px`, flex gap 6):
- Botão **✓ Aprovar** (primário, flex 1): bg `accent`, color invertido, padding `8px 12px`, radius 7, fontSize 12.5 / 600
- Botão "Editar" (secundário, flex 1): bg transparent, border 1px `borderStrong`, color `text`

##### Field component (drawer)
- Label uppercase 10/600/letter-spacing 0.5 `textFaint` margin-bottom 2
- Value 12.5px (mono se for número/código)

## Interactions & Behavior

### Cliques
- **Row de item** → abre detail drawer (componente acima)
- **Status pill** → abre status popover (não navega)
- **Checkbox** (stopPropagation) → toggle seleção, atualiza batch toolbar
- **Header do card de PV/OS** → colapsa/expande items
- **Célula editável** → entra em modo edição
- **KPI** → filtra lista por aquele status
- **Chip de status** ("Todos / Aprovados / …") → filtro persistente
- **+ Facet** → abre dropdown de seleção multi (mantém comportamento de `FacetDropdown` atual com checkbox + busca interna)
- **⌘K hero** → abre comando-K overlay (fase 2 — escopo separado)
- **Click outside** popover/drawer → fecha

### Animações
- Drawer entra: slide from right 250ms cubic-bezier(.2, .7, .3, 1)
- Drawer sai: idem reverso
- Popover: fade + slide-down 8px, 120ms ease-out
- Batch toolbar: fade + translate-y 12 → 0, 180ms ease-out
- Hover de row: bg transition 80ms

### Estados
- **Empty** (sem buckets após filtro): card único centrado "Nenhum PV/OS encontrado pra esses filtros" + botão "Limpar filtros"
- **Loading inicial**: skeleton de 3 cards de PV/OS (header + pipeline esqueleto + 2-3 rows shimmer)
- **Erro de fetch**: banner topo `bg-rose-50` (mantém o existente do `page.tsx`)
- **Salvando célula**: input fica com `editLine` em pulse animation (mantém comportamento atual)
- **Erro ao salvar célula**: bg `rose-50` border `rose-400` (mantém atual)
- **Sem projeto atribuído** (existe hoje): banner `bg-amber-50/60` clicável vira filtro `sem_projeto` — mantém

### Permissions
Mantém os 4 roles do bundle original (`admin`, `aprovador`, `comprador`, `viewer`). A badge "Comprador · edita PV/OS · RC · PC · Log" no top bar reflete o role atual. Comportamentos:
- `viewer`: tudo readonly, esconder checkbox + botões de ação no drawer
- `comprador`: pode editar células de PV/OS, RC, PC, Log; **não** pode mudar status
- `aprovador`: pode mudar status (popover habilitado) + ações batch (Aprovar / Fat. Direto / Rejeitar)
- `admin`: tudo

### Responsive
Não é prioridade na fase 1 (app é desktop-first, ~20 internos). Mas a partir de 1280px o layout deve preservar:
- Sidebar pode colapsar pra 56px (só ícones) com toggle
- KPI strip vira scroll horizontal abaixo de 1100
- Drawer abaixo de 900px ocupa 90vw como modal

## State Management

Componente cliente (`"use client"`). Estados locais com `useState`:
- `openBucket: number` — índice do card aberto (-1 = todos colapsados, comportamento atual permite múltiplos abertos; manter)
- `drawerItem: object | null` — item exibido no drawer
- `statusPopover: { rowId, anchor: DOMRect } | null` — controla popover
- `selected: Set<string>` — IDs de itens selecionados
- `editingCell: string | null` — id da célula em modo edição (`{rowId}-{field}`)
- `query, statusFilter, facets` — já existem em `FiltersBar.tsx`, manter

Salvamento de células: chama Supabase upsert + `router.refresh()` (mantém padrão atual). A `EditableCell.tsx` existente já implementa — só atualizar visual.

## Design Tokens

### Colors

```ts
// Light
const D2_T_LIGHT = {
  bg:           "#f4f4f0",  // app background (warm off-white)
  panel:        "#ffffff",  // cards, sidebar, drawer
  border:       "#e3e3dc",  // hairlines
  borderStrong: "#c8c8be",  // emphasis borders, popover borders
  text:         "#0e0e0c",  // primary text
  textMuted:    "#5b5b54",  // secondary text
  textFaint:    "#8e8e84",  // tertiary, captions
  accent:       "#0e6e57",  // primary action (deep teal)
  accentSoft:   "#dbeee5",  // accent backgrounds (avatar bg, dot glow)
  rowHover:     "#f9f9f5",
  editHi:       "#fef9d6",  // editing cell background
  editLine:     "#cfb742",  // editing cell underline
  drawer:       "#ffffff",
  drawerHead:   "#f4f4f0",
};

// Dark
const D2_T_DARK = {
  bg:           "#0a0a08",
  panel:        "#141412",
  border:       "#23231e",
  borderStrong: "#34342c",
  text:         "#f1f1ea",
  textMuted:    "#a8a89e",
  textFaint:    "#6c6c61",
  accent:       "#3eba9a",
  accentSoft:   "#15302a",
  rowHover:     "#1a1a16",
  editHi:       "#3a3416",
  editLine:     "#6e6024",
  drawer:       "#141412",
  drawerHead:   "#0e0e0c",
};
```

### Status colors (mantém os 8 do bundle, mas refinado pra paleta sóbria)

```ts
// Light: [bg, fg]
APROVADO:             ["#0e6e57", "#fff"]
APROVADO_FAT_DIRETO:  ["#0e6493", "#fff"]
PRE_SELECAO:          ["#b8651a", "#fff"]
PENDENTE:             ["#1a1a18", "#fff"]
NAO_APROVADO:         ["#5223a4", "#fff"]
REJEITADO_VALIDADE:   ["#ede2ff", "#5223a4"]  // soft variant
CANCELAR_PEDIDO:      ["#b8253a", "#fff"]
N_A:                  ["#e3e3dc", "#5b5b54"]

// Dark: [bg, fg]
APROVADO:             ["#3eba9a", "#0a1812"]
APROVADO_FAT_DIRETO:  ["#5cb6ed", "#0a1622"]
PRE_SELECAO:          ["#e8a04a", "#1a0e02"]
PENDENTE:             ["#f1f1ea", "#0a0a08"]
NAO_APROVADO:         ["#ad8af0", "#1a0e2c"]
REJEITADO_VALIDADE:   ["#2a1c45", "#c2a8e8"]
CANCELAR_PEDIDO:      ["#ed5f7a", "#280a10"]
N_A:                  ["#23231e", "#a8a89e"]
```

> **Migração das classes Tailwind**: estenda `tailwind.config.ts` com esses tokens (`brand` namespace ou `ww`). Mantenha o `safelist` existente pra não quebrar pills antigas durante a migração.

### Typography

- **UI**: `"Inter", -apple-system, BlinkMacSystemFont, system-ui, sans-serif`
- **Mono** (códigos, valores monetários, labels uppercase): `"JetBrains Mono", "SF Mono", ui-monospace, monospace`
- Use `font-variant-numeric: tabular-nums` em qualquer coluna numérica

Type scale:
| Uso                     | Size  | Weight | Letter-spacing |
|-------------------------|-------|--------|----------------|
| H1 da página            | 18px  | 600    | -0.4           |
| Valor KPI               | 22px  | 600    | -0.6           |
| PV/OS no card           | 13px  | 600    | -0.2           |
| Valor PV (header card)  | 14px  | 600    | -0.3           |
| Body / row text         | 12.5px| 400    | 0              |
| Secondary text          | 11.5px| 400    | 0              |
| Caption / metadata mono | 10-11px| 500   | 0.4-0.5        |
| UPPERCASE label         | 10px  | 600    | 0.5-0.6        |

### Spacing & Radii

- Card padding: `14px 18px` (main), `12px 16px` (card header), `8px 16px` (rows)
- Gap entre cards: 10px
- Card radius: 10px
- Pill radius: 4px (status), 6px (chips de filtro)
- Popover radius: 10px
- Input radius: 7px (drawer buttons), 6px (inline)

### Shadows

- Card normal: nenhuma
- Card hover: nenhuma (preferimos bg shift)
- Hero command bar (light only): `0 1px 0 rgba(0,0,0,.03), 0 6px 20px -14px rgba(0,0,0,.1)`
- Popover: `0 14px 40px rgba(0,0,0,.18), 0 0 0 1px rgba(0,0,0,.04)`
- Drawer: `-12px 0 40px -20px rgba(0,0,0,.15)`
- Batch toolbar: `0 12px 32px rgba(0,0,0,.25)`

## Assets

Nenhum asset binário — tudo é tipografia + cor + SVG inline (chevrons, search icon, sparkline polyline, dots de pipeline). Logo "WW" é um div com background-color e iniciais — substitua pelo logo real do Waterworks quando disponível.

## Files

- `design-files/D-bold-v2.jsx` — **componente principal**, é a versão final e deve ser a referência primária. Contém:
  - `D2Pane({ mode })` — root da página (passe `"light"` ou `"dark"`)
  - `D2Card` — card de PV/OS com pipeline
  - `D2Pipeline` — componente do pipeline horizontal
  - `D2StatusPill` + `D2StatusPopover` — sistema de status
  - `D2Drawer` — detail drawer
  - `D2EditCell` — célula editável
  - `D2NavItem`, `D2Spark`, `D2Field` — primitivos
- `design-files/D-bold.jsx` — versão v1 (mantida pra referência; menos completa)
- `design-files/data.jsx` — schema mockado, mostra estrutura de buckets e items, status enum, helpers `fmtBRL`, `fmtNum`, `summarize`. **Importante**: mostra como agrupar PV/OS → items.
- `design-files/original-bundle.md` — bundle original com tokens Tailwind e snippets dos componentes existentes do app (`FiltersBar`, `EditableCell`, `EditableStatusCell`, `GroupedModuleView`)

## Migration plan (sugestão)

1. **Tokens** — adicione tokens de cor no `tailwind.config.ts`
2. **Componente novo `BucketCard.tsx`** — substitui parte da `GroupedModuleView` (a renderização de cada bucket); mantém os filtros e batch state no parent
3. **Refactor `EditableCell.tsx`** — troque o estilo amarelo cheio pelo dashed underline novo (poucas linhas)
4. **Refactor `EditableStatusCell.tsx`** — atualize as classes da pill e o estilo do menu portal
5. **Adicione `DetailDrawer.tsx`** — novo componente, slide-in da direita; query de atividade no useEffect
6. **Adicione `BatchToolbar.tsx`** — flutuante; já existe lógica de batch select, só novo skin
7. **Adicione `CommandBar.tsx`** — placeholder no header (overlay ⌘K real é fase 2)
8. **Sidebar global** — extraia pro `app/(app)/layout.tsx` pra unificar Avulsas/Projetos/PCs

Faseamento sugerido: tokens + cards (visual core) na PR 1; drawer + batch + popover na PR 2; sidebar unificada + ⌘K na PR 3.
